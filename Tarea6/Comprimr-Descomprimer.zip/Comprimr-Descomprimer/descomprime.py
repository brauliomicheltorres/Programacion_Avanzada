#!/usr/bin/env python3
"""
descomprime.py - Programa de descompresión de archivos usando codificación Huffman.

Uso:
    python descomprime.py <archivo_comprimido.huff> [archivo_restaurado]
"""

import sys
import os
import struct
from huffman import (
    deserialize_tree,
    BitReader,
    HuffmanNode
)

MAGIC_NUMBER = b"HF"


def descomprimir_archivo(ruta_origen: str, ruta_destino: str):
    if not os.path.exists(ruta_origen):
        print(f"Error: El archivo '{ruta_origen}' no existe.", file=sys.stderr)
        sys.exit(1)

    tam_archivo = os.path.getsize(ruta_origen)
    if tam_archivo < 13:
        # Magic (2) + Pad (1) + TamArbol (2) + TamOrig (8) = 13 bytes mínimos
        print("Error: El archivo está corrupto o es demasiado pequeño para tener un encabezado válido.", file=sys.stderr)
        sys.exit(1)

    with open(ruta_origen, "rb") as f_in:
        # 1. Validar Magic Number
        magic = f_in.read(2)
        if magic != MAGIC_NUMBER:
            print(f"Error: Formato inválido. Magic esperado '{MAGIC_NUMBER}', recibido '{magic}'.", file=sys.stderr)
            sys.exit(1)

        # 2. Leer metadatos fijos del Header
        padding_datos = struct.unpack(">B", f_in.read(1))[0]
        tam_arbol = struct.unpack(">H", f_in.read(2))[0]
        tam_original = struct.unpack(">Q", f_in.read(8))[0]

        # Caso archivo vacío
        if tam_original == 0:
            with open(ruta_destino, "wb") as f_out:
                pass
            print(f"[OK] Archivo vacío reconstruido en '{ruta_destino}'.")
            return

        # 3. Leer y deserializar el árbol de Huffman
        bytes_arbol = f_in.read(tam_arbol)
        if len(bytes_arbol) < tam_arbol:
            print("Error: No se pudo leer el árbol completo del encabezado.", file=sys.stderr)
            sys.exit(1)

        reader_arbol = BitReader(bytes_arbol)
        arbol = deserialize_tree(reader_arbol)
        if arbol is None:
            print("Error: Falla al reconstruir el árbol de Huffman.", file=sys.stderr)
            sys.exit(1)

        # 4. Leer datos comprimidos
        datos_comprimidos = f_in.read()

    # 5. Decodificar el flujo de bits
    reader_datos = BitReader(datos_comprimidos)
    total_bits = (len(datos_comprimidos) * 8) - padding_datos

    datos_reconstruidos = bytearray()
    curr_node = arbol
    bits_leidos = 0

    # Decodificación bit a bit guiada por el árbol
    while bits_leidos < total_bits and len(datos_reconstruidos) < tam_original:
        bit = reader_datos.read_bit()
        if bit is None:
            break
        bits_leidos += 1

        if bit == 0:
            curr_node = curr_node.left
        else:
            curr_node = curr_node.right

        if curr_node is not None and curr_node.is_leaf():
            datos_reconstruidos.append(curr_node.byte_val)
            curr_node = arbol

    # 6. Escribir archivo restaurado
    with open(ruta_destino, "wb") as f_out:
        f_out.write(datos_reconstruidos)

    tam_descomprimido = len(datos_reconstruidos)
    print("--- Descompresión Exitosa ---")
    print(f"Archivo origen:       {ruta_origen} ({tam_archivo} bytes)")
    print(f"Archivo restaurado:   {ruta_destino} ({tam_descomprimido} bytes)")
    if tam_descomprimido == tam_original:
        print("[OK] El tamaño coincide exactamente con el original.")
    else:
        print(f"[AVISO] Tamaño esperado {tam_original} bytes, obtenido {tam_descomprimido} bytes.")


def main():
    if len(sys.argv) < 2:
        print("Uso: python descomprime.py <archivo_comprimido.huff> [archivo_restaurado]")
        sys.exit(1)

    ruta_origen = sys.argv[1]
    if len(sys.argv) >= 3:
        ruta_destino = sys.argv[2]
    else:
        # Si termina en .huff, quitárselo; si no, agregar .orig
        if ruta_origen.endswith(".huff"):
            ruta_destino = ruta_origen[:-5]
            if not ruta_destino:
                ruta_destino = "restaurado.bin"
        else:
            ruta_destino = ruta_origen + ".orig"

    descomprimir_archivo(ruta_origen, ruta_destino)


if __name__ == "__main__":
    main()

# Documento de Especificación: Formato de Archivo Comprimido Huffman (.huff)

**Materia:** Análisis y Diseño de Algoritmos (ADA)  
**Autor:** Alumno  
**Fecha:** Octubre 2026  

---

## 1. Introducción y Justificación del Formato

El propósito de este proyecto es implementar un sistema completo de compresión y descompresión de datos sin pérdida (*lossless*) mediante el algoritmo de **Huffman**, capaz de procesar cualquier tipo de archivo (texto, imágenes, binarios, ejecutables).

Un archivo comprimido por Huffman debe ser autosuficiente: el descompresor no dispone de la tabla de frecuencias original ni del árbol en memoria. Por ello, el archivo se organiza en dos bloques principales:
$$\text{[ HEADER | DATOS COMPRIMIDOS ]}$$

### ¿Cómo guardar el árbol de Huffman?
Se evaluaron tres opciones principales:
1. **Guardar la tabla de frecuencias:** Requiere almacenar 4 u 8 bytes por cada símbolo presente (hasta $256 \times 8 = 2048$ bytes) y forzar al descompresor a reconstruir el montículo y el árbol.
2. **Guardar la lista de códigos binarios:** Es ineficiente por el sobrecosto de delimitadores y longitudes de prefijo variables.
3. **Serializar directamente la estructura del árbol en preorden (Método Seleccionado):**  
   Es la técnica más compacta y elegante. Cada nodo interno se codifica con **1 bit (`0`)** y cada hoja con **1 bit (`1`) seguido inmediatamente por los 8 bits del byte del símbolo**.  
   Para un alfabeto de $U$ símbolos distintos, el árbol tiene exactamente $U$ hojas y $U-1$ nodos internos. El espacio total requerido para serializar el árbol es de únicamente:
   $$\text{Bits del árbol} = (U - 1) \cdot 1 + U \cdot (1 + 8) = 10U - 1 \text{ bits}$$
   Incluso con los 256 bytes posibles presentes, el árbol completo ocupa a lo sumo **320 bytes**, reduciendo drásticamente el *overhead* del encabezado.

---

## 2. Especificación Detallada del Header

La estructura en bytes del archivo `.huff` está definida de la siguiente manera:

| Campo | Tipo / Tamaño | Descripción |
| :--- | :--- | :--- |
| **Magic Number** | 2 bytes (`b'HF'`) | Identificador único del formato (0x48, 0x46). Permite al descompresor comprobar la validez del archivo. |
| **Padding de Datos** | 1 byte (`uint8`) | Cantidad de bits añadidos (0 a 7) al último byte del flujo de datos para alinear a 8 bits. |
| **Tamaño del Árbol** | 2 bytes (`uint16`, Big-Endian) | Longitud en bytes de la sección del árbol serializado ($T$). |
| **Tamaño Original** | 8 bytes (`uint64`, Big-Endian) | Tamaño exacto del archivo sin comprimir en bytes (permite cortar la decodificación de forma exacta). |
| **Árbol Serializado** | $T$ bytes | Estructura en preorden del árbol descrita a nivel de bits. |
| **Datos Comprimidos** | Resto del archivo | Flujo de bits concatenados de los códigos Huffman asignados a cada byte. |

---

## 3. Algoritmo de Reconstrucción del Árbol

El descompresor inicializa un lector de bits (`BitReader`) sobre los $T$ bytes del árbol:
1. Lee un bit.
2. Si el bit es `1`: sabe que es una **hoja**. Lee inmediatamente los siguientes 8 bits y crea un `NodoHoja(simbolo)`.
3. Si el bit es `0`: sabe que es un **nodo interno**. Invoca recursivamente el deserializador para el hijo izquierdo (`left`) y luego para el hijo derecho (`right`), devolviendo `NodoInterno(left, right)`.

Una vez instanciado el árbol en memoria, el descompresor procesa el flujo de datos comprimidos bit a bit: parte de la raíz, avanza a la izquierda con `0` o a la derecha con `1`. Al alcanzar una hoja, emite el byte correspondiente al archivo de salida y regresa de inmediato a la raíz del árbol.

---

## 4. Resultados de las Pruebas Experimentales

Se llevaron a cabo pruebas con distintos tipos de archivo para evaluar el desempeño y verificar la integridad total (comparando con `cmp` / hashes MD5):

| Tipo de Archivo | Nombre | Tamaño Original | Tamaño Comprimido | Tasa de Compresión | Ahorro de Espacio | Integridad |
| :--- | :--- | :--- | :--- | :--- | :--- | :--- |
| **Texto plano** | `test_texto.txt` | 4,300 bytes | 2,292 bytes | 53.30% | **46.70%** | Idéntico (OK) |
| **Imagen BMP (sin compresión previa)** | `muestra.bmp` | 43,254 bytes | 41,713 bytes | 96.44% | **3.56%** | Idéntico (OK) |
| **Binario simulado** | `test_binario.bin` | 5,000 bytes | 4,912 bytes | 98.24% | **1.76%** | Idéntico (OK) |

### Conclusiones
- En archivos de texto plano con redundancia natural, el algoritmo alcanza ahorros superiores al **45%**.
- En archivos binarios e imágenes sin compresión previa, el algoritmo genera archivos válidos sin pérdida alguna, demostrando la versatilidad de operar directamente sobre el flujo de bytes de $0$ a $255$.

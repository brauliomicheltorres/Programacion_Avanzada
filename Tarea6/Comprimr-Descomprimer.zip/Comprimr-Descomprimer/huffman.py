import heapq
from collections import Counter
from typing import Optional, Dict, Tuple

class HuffmanNode:
    """Nodo para el árbol de Huffman."""
    def __init__(self, byte_val: Optional[int] = None, freq: int = 0,
                 left: Optional['HuffmanNode'] = None, right: Optional['HuffmanNode'] = None):
        self.byte_val = byte_val  # Valor del byte (0 a 255), None si es nodo interno
        self.freq = freq          # Frecuencia de aparición
        self.left = left          # Hijo izquierdo (convención: bit '0')
        self.right = right        # Hijo derecho (convención: bit '1')

    def is_leaf(self) -> bool:
        return self.left is None and self.right is None

    def __lt__(self, other: 'HuffmanNode') -> bool:
        # Comparación requerida por el montículo (heapq)
        return self.freq < other.freq


class BitWriter:
    """Utilidad para escribir bits individuales a un búfer de bytes."""
    def __init__(self):
        self.bytes_out = bytearray()
        self.current_byte = 0
        self.bit_count = 0

    def write_bit(self, bit: int):
        self.current_byte = (self.current_byte << 1) | (bit & 1)
        self.bit_count += 1
        if self.bit_count == 8:
            self.bytes_out.append(self.current_byte)
            self.current_byte = 0
            self.bit_count = 0

    def write_byte(self, byte_val: int):
        # Escribe los 8 bits de un byte
        for i in range(7, -1, -1):
            self.write_bit((byte_val >> i) & 1)

    def write_bits(self, bit_str: str):
        for ch in bit_str:
            self.write_bit(1 if ch == '1' else 0)

    def flush(self) -> int:
        """Rellena con ceros hasta completar el último byte si es necesario.
        Retorna la cantidad de bits de padding agregados (0 a 7).
        """
        if self.bit_count > 0:
            pad = 8 - self.bit_count
            self.current_byte <<= pad
            self.bytes_out.append(self.current_byte)
            self.current_byte = 0
            self.bit_count = 0
            return pad
        return 0


class BitReader:
    """Utilidad para leer bits individuales a partir de un flujo de bytes."""
    def __init__(self, data: bytes):
        self.data = data
        self.byte_index = 0
        self.bit_index = 0  # 0 a 7 (de más significativo a menos significativo)

    def read_bit(self) -> Optional[int]:
        if self.byte_index >= len(self.data):
            return None
        bit = (self.data[self.byte_index] >> (7 - self.bit_index)) & 1
        self.bit_index += 1
        if self.bit_index == 8:
            self.bit_index = 0
            self.byte_index += 1
        return bit

    def read_byte(self) -> Optional[int]:
        val = 0
        for _ in range(8):
            b = self.read_bit()
            if b is None:
                return None
            val = (val << 1) | b
        return val


def build_huffman_tree(data: bytes) -> Optional[HuffmanNode]:
    """Construye el árbol de Huffman a partir de un buffer de bytes."""
    if not data:
        return None

    frequencies = Counter(data)
    heap = []

    for byte_val, freq in frequencies.items():
        node = HuffmanNode(byte_val=byte_val, freq=freq)
        heapq.heappush(heap, node)

    # Caso especial: sólo hay un byte único en todo el archivo
    if len(heap) == 1:
        single_node = heapq.heappop(heap)
        parent = HuffmanNode(freq=single_node.freq, left=single_node, right=None)
        return parent

    while len(heap) > 1:
        n1 = heapq.heappop(heap)
        n2 = heapq.heappop(heap)
        parent = HuffmanNode(freq=n1.freq + n2.freq, left=n1, right=n2)
        heapq.heappush(heap, parent)

    return heap[0]


def build_codes(root: Optional[HuffmanNode]) -> Dict[int, str]:
    """Genera la tabla de códigos Huffman {byte: '0101...'}."""
    codes: Dict[int, str] = {}
    if root is None:
        return codes

    def traverse(node: HuffmanNode, current_code: str):
        if node.is_leaf():
            # Si sólo hay un nodo hoja como hijo único, el código mínimo es '0'
            codes[node.byte_val] = current_code if current_code else "0"
            return
        if node.left:
            traverse(node.left, current_code + "0")
        if node.right:
            traverse(node.right, current_code + "1")

    traverse(root, "")
    return codes


def serialize_tree(root: Optional[HuffmanNode]) -> Tuple[bytes, int]:
    """Serializa el árbol de Huffman en preorden a nivel de bits:
    - 0 para nodo interno
    - 1 seguido de 8 bits para nodo hoja
    Retorna (bytes_serializados, bits_de_padding_al_final).
    """
    if root is None:
        return b"", 0

    writer = BitWriter()

    def traverse(node: HuffmanNode):
        if node.is_leaf():
            writer.write_bit(1)
            writer.write_byte(node.byte_val)
        else:
            writer.write_bit(0)
            if node.left:
                traverse(node.left)
            if node.right:
                traverse(node.right)

    traverse(root)
    pad = writer.flush()
    return bytes(writer.bytes_out), pad


def deserialize_tree(reader: BitReader) -> Optional[HuffmanNode]:
    """Reconstruye el árbol de Huffman a partir de un BitReader en preorden."""
    bit = reader.read_bit()
    if bit is None:
        return None

    if bit == 1:
        # Nodo hoja: leer los siguientes 8 bits
        byte_val = reader.read_byte()
        if byte_val is None:
            raise ValueError("Flujo de bits incompleto al leer hoja del árbol")
        return HuffmanNode(byte_val=byte_val)
    else:
        # Nodo interno
        left = deserialize_tree(reader)
        right = deserialize_tree(reader)
        return HuffmanNode(left=left, right=right)

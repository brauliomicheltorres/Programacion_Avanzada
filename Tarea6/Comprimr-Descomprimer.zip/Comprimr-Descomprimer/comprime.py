#!/usr/bin/env python3
"""
comprime.py - Programa de compresión de archivos usando codificación Huffman.

Uso:
    python comprime.py <archivo_origen> [archivo_destino.huff]
"""

import sys
import os
import struct
from huffman import (
    build_huffman_tree,
    build_codes,
    serialize_tree,
    BitWriter
)

MAGIC_NUMBER = b"HF"  # 2 bytes identificadores


def comprimir_archivo(ruta_origen: str, ruta_destino: str):
    if not os.path.exists(ruta_origen):
        print(f"Error: El archivo '{ruta_origen}' no existe.", file=sys.stderr)
        sys.exit(1)

    tam_original = os.path.getsize(ruta_origen)

    # Caso 1: Archivo vacío
    if tam_original == 0:
        with open(ruta_destino, "wb") as f_out:
            # Magic + padding 0 + arbol tam 0 + original size 0
            f_out.write(MAGIC_NUMBER)
            f_out.write(struct.pack(">B", 0))  # 1 byte: padding datos
            f_out.write(struct.pack(">H", 0))  # 2 bytes: tam arbol
            f_out.write(struct.pack(">Q", 0))  # 8 bytes: tamaño original
        print(f"[OK] Archivo vacío comprimido con éxito en '{ruta_destino}'.")
        return

    with open(ruta_origen, "rb") as f_in:
        datos_originales = f_in.read()

    # 1. Construir árbol y tabla de códigos
    arbol = build_huffman_tree(datos_originales)
    tabla_codigos = build_codes(arbol)

    # 2. Serializar el árbol de Huffman
    bytes_arbol, _ = serialize_tree(arbol)
    tam_arbol = len(bytes_arbol)

    # 3. Codificar los datos con BitWriter
    writer_datos = BitWriter()
    for b in datos_originales:
        writer_datos.write_bits(tabla_codigos[b])

    padding_datos = writer_datos.flush()
    datos_comprimidos = bytes(writer_datos.bytes_out)

    # 4. Construir el archivo comprimido con HEADER
    # Formato Header:
    # [Magic (2B)] [PaddingDatos (1B)] [TamArbol (2B)] [TamOriginal (8B)] [ArbolSerializado (TamArbol B)]
    with open(ruta_destino, "wb") as f_out:
        f_out.write(MAGIC_NUMBER)
        f_out.write(struct.pack(">B", padding_datos))
        f_out.write(struct.pack(">H", tam_arbol))
        f_out.write(struct.pack(">Q", tam_original))
        f_out.write(bytes_arbol)
        f_out.write(datos_comprimidos)

    tam_comprimido = os.path.getsize(ruta_destino)
    tasa = (tam_comprimido / tam_original) * 100 if tam_original > 0 else 0
    ahorro = 100 - tasa

    print(f"--- Compresión Exitosa ---")
    print(f"Archivo origen:      {ruta_origen} ({tam_original} bytes)")
    print(f"Archivo destino:     {ruta_destino} ({tam_comprimido} bytes)")
    print(f"Tamaño del árbol:    {tam_arbol} bytes en header")
    print(f"Tasa de compresión:  {tasa:.2f}% (Ahorro de espacio: {ahorro:.2f}%)")


def main():
    if len(sys.argv) < 2:
        print("Uso: python comprime.py <archivo_origen> [archivo_destino.huff]")
        sys.exit(1)

    ruta_origen = sys.argv[1]
    if len(sys.argv) >= 3:
        ruta_destino = sys.argv[2]
    else:
        ruta_destino = ruta_origen + ".huff"

    comprimir_archivo(ruta_origen, ruta_destino)


if __name__ == "__main__":
    main()

#!/bin/bash
# setup.sh — Instala numpy y ejecuta el benchmark completo
# Uso: bash setup.sh

set -e
VENV_DIR="$(dirname "$0")/venv"

echo "=== Configurando entorno ==="
# Intentar crear venv
if python3 -m ensurepip --version &>/dev/null; then
    python3 -m venv "$VENV_DIR"
    source "$VENV_DIR/bin/activate"
    pip install numpy --quiet
    echo "numpy instalado en venv."
elif command -v pip3 &>/dev/null; then
    pip3 install --user numpy --quiet
    echo "numpy instalado con pip3 --user."
else
    echo "Instala numpy manualmente:"
    echo "  sudo apt install python3-numpy   # Debian/Ubuntu"
    echo "  conda install numpy              # Conda"
    exit 1
fi

echo ""
echo "=== Ejecutando benchmark ==="
python3 "$(dirname "$0")/benchmark.py"

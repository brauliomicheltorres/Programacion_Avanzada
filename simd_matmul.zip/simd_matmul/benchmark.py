"""
benchmark.py — Comparación: naive vs AVX2 vs NumPy
Usa ctypes para cargar libmatmul.so y medir el rendimiento.
"""

import ctypes
import pathlib
import time

import numpy as np

# ─────────────────────────────────────────────────────────────────────────────
# 1. Cargar la biblioteca
# ─────────────────────────────────────────────────────────────────────────────
LIB_PATH = pathlib.Path(__file__).parent / "libmatmul.so"
lib = ctypes.CDLL(str(LIB_PATH))

# Firmas de las funciones  (float*, float*, float*, int, int, int)
_ptr_f = ctypes.POINTER(ctypes.c_float)

for fname in ("matmul_naive", "matmul_avx2"):
    fn = getattr(lib, fname)
    fn.restype  = None
    fn.argtypes = [_ptr_f, _ptr_f, _ptr_f,
                   ctypes.c_int, ctypes.c_int, ctypes.c_int]

# ─────────────────────────────────────────────────────────────────────────────
# 2. Helpers
# ─────────────────────────────────────────────────────────────────────────────
def as_ptr(arr: np.ndarray) -> ctypes.POINTER(ctypes.c_float):
    """Devuelve puntero C a un array NumPy float32 contiguo."""
    assert arr.dtype == np.float32 and arr.flags["C_CONTIGUOUS"]
    return arr.ctypes.data_as(_ptr_f)


def run(fn, A, B, C):
    """Llama a la función de la biblioteca con los arreglos dados."""
    M, K = A.shape
    _, N  = B.shape
    fn(as_ptr(A), as_ptr(B), as_ptr(C), M, K, N)


def benchmark(fn, A, B, reps: int = 5) -> tuple[float, np.ndarray]:
    """
    Ejecuta `fn` `reps` veces y devuelve (tiempo_medio_s, resultado_C).
    La primera pasada es de calentamiento (warm-up).
    """
    M, N = A.shape[0], B.shape[1]
    # Warm-up
    C = np.zeros((M, N), dtype=np.float32)
    run(fn, A, B, C)

    times = []
    for _ in range(reps):
        C = np.zeros((M, N), dtype=np.float32)
        t0 = time.perf_counter()
        run(fn, A, B, C)
        times.append(time.perf_counter() - t0)

    return float(np.median(times)), C


# ─────────────────────────────────────────────────────────────────────────────
# 3. Datos de prueba
# ─────────────────────────────────────────────────────────────────────────────
np.random.seed(42)
M, K, N = 512, 512, 512          # matrices cuadradas 512×512

A = np.random.randn(M, K).astype(np.float32)
B = np.random.randn(K, N).astype(np.float32)

print(f"\nMatrices: A={M}×{K}  B={K}×{N}  (float32)\n")
print(f"{'Implementación':<18} {'Tiempo (s)':>12} {'GFLOP/s':>10} {'Aceleración':>12}")
print("─" * 56)

FLOPS = 2 * M * K * N   # multiplicaciones + sumas

results = {}
times   = {}

# ── Naive ────────────────────────────────────────────────────────────────────
t_naive, C_naive = benchmark(lib.matmul_naive, A, B, reps=3)
results["naive"] = C_naive
times["naive"]   = t_naive
gflops_naive     = FLOPS / t_naive / 1e9
print(f"{'C++ Naive':<18} {t_naive:>12.4f} {gflops_naive:>10.2f} {'1.00×':>12}")

# ── AVX2 ─────────────────────────────────────────────────────────────────────
t_avx2, C_avx2 = benchmark(lib.matmul_avx2, A, B, reps=5)
results["avx2"] = C_avx2
times["avx2"]   = t_avx2
gflops_avx2     = FLOPS / t_avx2 / 1e9
speedup_avx2    = t_naive / t_avx2
print(f"{'C++ AVX2':<18} {t_avx2:>12.4f} {gflops_avx2:>10.2f} {speedup_avx2:>11.2f}×")

# ── NumPy (BLAS) ──────────────────────────────────────────────────────────────
# Warm-up
_ = A @ B
t0 = time.perf_counter()
for _ in range(5):
    C_np = (A @ B)
t_numpy = (time.perf_counter() - t0) / 5
results["numpy"]  = C_np
times["numpy"]    = t_numpy
gflops_numpy      = FLOPS / t_numpy / 1e9
speedup_numpy     = t_naive / t_numpy
print(f"{'NumPy (BLAS)':<18} {t_numpy:>12.4f} {gflops_numpy:>10.2f} {speedup_numpy:>11.2f}×")

print("─" * 56)

# ─────────────────────────────────────────────────────────────────────────────
# 4. Verificación de correctitud
# ─────────────────────────────────────────────────────────────────────────────
ref = A.astype(np.float64) @ B.astype(np.float64)   # referencia doble precisión

def max_err(C, name):
    err = np.max(np.abs(C.astype(np.float64) - ref))
    print(f"  Error máximo {name:10s}: {err:.2e}")

print("\nVerificación de correctitud (vs referencia float64):")
max_err(results["naive"], "Naive")
max_err(results["avx2"],  "AVX2")
max_err(results["numpy"], "NumPy")

# ─────────────────────────────────────────────────────────────────────────────
# 5. Resumen
# ─────────────────────────────────────────────────────────────────────────────
print(f"\nResumen:")
print(f"  AVX2 es {speedup_avx2:.1f}× más rápido que el código naive.")
print(f"  NumPy/BLAS es {speedup_numpy:.1f}× más rápido que el código naive.")
print(f"  (NumPy usa rutinas BLAS altamente optimizadas como referencia de techo.)\n")

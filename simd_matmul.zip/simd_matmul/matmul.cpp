/**
 * matmul.cpp — Multiplicación de matrices con AVX2 intrinsics
 *
 * Expone dos funciones en C:
 *   matmul_naive  : versión escalar (referencia)
 *   matmul_avx2   : versión SIMD con AVX2 (8 floats por ciclo de registro)
 *
 * Compilar:
 *   g++ -O3 -march=native -mavx2 -ffast-math -shared -fPIC \
 *       -o libmatmul.so matmul.cpp
 */

#include <immintrin.h>   // AVX / AVX2 intrinsics
#include <cstring>       // memset
#include <cstdint>

// ─────────────────────────────────────────────────────────────────────────────
// Versión escalar — referencia sin optimizar
// C = A * B  donde A[M×K], B[K×N], C[M×N]  (row-major, float32)
// ─────────────────────────────────────────────────────────────────────────────
extern "C"
void matmul_naive(const float* __restrict__ A,
                  const float* __restrict__ B,
                  float*       __restrict__ C,
                  int M, int K, int N)
{
    for (int i = 0; i < M; ++i)
        for (int k = 0; k < K; ++k) {
            float a_ik = A[i * K + k];
            for (int j = 0; j < N; ++j)
                C[i * N + j] += a_ik * B[k * N + j];
        }
}

// ─────────────────────────────────────────────────────────────────────────────
// Versión AVX2 con tiling de caché y blocking de registros
//
// Estrategia de 3 niveles:
//
//  1. TILING DE CACHÉ (tiles de IB×KB×JB):
//       Recorre las matrices en bloques que caben en L2/L1 para maximizar
//       la reutilización de datos antes de que sean desalojados.
//       IB=64, KB=256, JB=256  (≈ 1.5 MB por tile → cabe en L2 de 4 MB).
//
//  2. MICRO-KERNEL 6×32 (6 filas de A, 32 cols de C simultáneas):
//       Mantiene 6×4 = 24 registros AVX como acumuladores, minimizando
//       las cargas/stores a memoria y ocultando la latencia de FMA (5 ciclos).
//
//  3. INTRINSICS EXPLÍCITOS:
//       _mm256_set1_ps    — broadcast de escalar a 256 bits
//       _mm256_fmadd_ps   — Fused Multiply-Add (a*b + c) en un ciclo
//       _mm256_loadu_ps / _mm256_storeu_ps — carga/store sin restricción de alineación
// ─────────────────────────────────────────────────────────────────────────────

// Tamaños de tile (tuneable)
static constexpr int IB = 64;    // filas de A por tile de caché
static constexpr int KB = 256;   // columnas de A / filas de B por tile
static constexpr int JB = 256;   // columnas de B/C por tile

// Micro-kernel: acumula C[i0:i0+MR, j0:j0+NR] += A[i0:i0+MR, k] * B[k, j0:j0+NR]
// MR=6 filas, NR=32 cols (4 registros AVX de 8 floats c/u)
static constexpr int MR = 6;
static constexpr int NR = 32;   // 4 × 8 floats

static inline void micro_kernel(
    const float* __restrict__ A, int lda,
    const float* __restrict__ B, int ldb,
    float*       __restrict__ C, int ldc,
    int mr, int kc, int nr)
{
    // Acumuladores: mr filas × (nr/8) registros AVX
    __m256 acc[MR][4] = {};

    // Inicializar acumuladores con los valores actuales de C
    for (int i = 0; i < mr; ++i)
        for (int t = 0; t < 4 && t*8 < nr; ++t)
            acc[i][t] = _mm256_loadu_ps(C + i * ldc + t * 8);

    // Bucle sobre la dimensión K interna del tile
    for (int k = 0; k < kc; ++k) {
        for (int i = 0; i < mr; ++i) {
            __m256 av = _mm256_set1_ps(A[i * lda + k]);
            for (int t = 0; t < 4 && t*8 < nr; ++t)
                acc[i][t] = _mm256_fmadd_ps(av, _mm256_loadu_ps(B + k * ldb + t * 8), acc[i][t]);
        }
    }

    // Almacenar acumuladores en C
    for (int i = 0; i < mr; ++i)
        for (int t = 0; t < 4 && t*8 < nr; ++t)
            _mm256_storeu_ps(C + i * ldc + t * 8, acc[i][t]);
}

extern "C"
void matmul_avx2(const float* __restrict__ A,
                 const float* __restrict__ B,
                 float*       __restrict__ C,
                 int M, int K, int N)
{
    // Inicializar C a cero
    memset(C, 0, M * N * sizeof(float));

    // Tiling de caché: i → k → j
    for (int i0 = 0; i0 < M; i0 += IB) {
        int ib = (i0 + IB < M) ? IB : M - i0;

        for (int k0 = 0; k0 < K; k0 += KB) {
            int kb = (k0 + KB < K) ? KB : K - k0;

            for (int j0 = 0; j0 < N; j0 += JB) {
                int jb = (j0 + JB < N) ? JB : N - j0;

                // Micro-kernels dentro del tile
                for (int i = i0; i < i0 + ib; i += MR) {
                    int mr = (i + MR < i0 + ib) ? MR : i0 + ib - i;

                    for (int j = j0; j < j0 + jb; j += NR) {
                        int nr = (j + NR < j0 + jb) ? NR : j0 + jb - j;

                        micro_kernel(
                            A + i * K + k0, K,
                            B + k0 * N + j, N,
                            C + i * N + j,  N,
                            mr, kb, nr);
                    }
                }
            }
        }
    }
}

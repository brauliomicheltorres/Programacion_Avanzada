#!/usr/bin/env python3
"""
test_no_numpy.py — Prueba básica de la biblioteca libmatmul.so
sin dependencias externas (solo ctypes de la librería estándar).
"""

import ctypes, pathlib, array, time, math

LIB = ctypes.CDLL(str(pathlib.Path(__file__).parent / "libmatmul.so"))

_p = ctypes.POINTER(ctypes.c_float)
for fn in ("matmul_naive", "matmul_avx2"):
    f = getattr(LIB, fn)
    f.restype, f.argtypes = None, [_p, _p, _p, ctypes.c_int, ctypes.c_int, ctypes.c_int]

def make(rows, cols, val=None):
    n = rows * cols
    if val is None:
        import random
        data = [random.gauss(0,1) for _ in range(n)]
    else:
        data = [float(val)] * n
    return array.array('f', data)

def ptr(a): return (ctypes.c_float * len(a)).from_buffer(a)

# Prueba de correctitud: A(2×3) · B(3×2) calculado a mano
#   A = [[1,2,3],[4,5,6]], B = [[7,8],[9,10],[11,12]]
#   C[0,0] = 1*7+2*9+3*11 = 7+18+33 = 58
#   C[0,1] = 1*8+2*10+3*12 = 8+20+36 = 64
#   C[1,0] = 4*7+5*9+6*11 = 28+45+66 = 139
#   C[1,1] = 4*8+5*10+6*12 = 32+50+72 = 154

A = array.array('f', [1,2,3, 4,5,6])
B = array.array('f', [7,8, 9,10, 11,12])
C_naive = array.array('f', [0]*4)
C_avx2  = array.array('f', [0]*4)

LIB.matmul_naive(ptr(A), ptr(B), ptr(C_naive), 2, 3, 2)
LIB.matmul_avx2 (ptr(A), ptr(B), ptr(C_avx2),  2, 3, 2)

ref = [58.0, 64.0, 139.0, 154.0]
print("=== Prueba de correctitud (2×3 · 3×2) ===")
print(f"  Referencia: {ref}")
print(f"  Naive:      {list(C_naive)}")
print(f"  AVX2:       {list(C_avx2)}")
ok_n = all(abs(a-b) < 1e-3 for a,b in zip(C_naive, ref))
ok_a = all(abs(a-b) < 1e-3 for a,b in zip(C_avx2,  ref))
print(f"  Naive {'✓ PASS' if ok_n else '✗ FAIL'}   AVX2 {'✓ PASS' if ok_a else '✗ FAIL'}")

# Mini-benchmark: 128×128
import random
M=K=N=128
A128 = array.array('f', [random.gauss(0,1) for _ in range(M*K)])
B128 = array.array('f', [random.gauss(0,1) for _ in range(K*N)])

def bench(fn, reps=5):
    times=[]
    for _ in range(reps):
        C = array.array('f',[0]*(M*N))
        t=time.perf_counter()
        fn(ptr(A128),ptr(B128),ptr(C),M,K,N)
        times.append(time.perf_counter()-t)
    return sorted(times)[reps//2]

t_n = bench(LIB.matmul_naive)
t_a = bench(LIB.matmul_avx2)
flops = 2*M*K*N
print(f"\n=== Mini-benchmark 128×128 (float32) ===")
print(f"  Naive : {t_n*1000:.2f} ms  |  {flops/t_n/1e9:.2f} GFLOP/s")
print(f"  AVX2  : {t_a*1000:.2f} ms  |  {flops/t_a/1e9:.2f} GFLOP/s")
print(f"  Aceleración: {t_n/t_a:.1f}×")

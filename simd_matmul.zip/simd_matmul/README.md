# Biblioteca C++ con Intrinsics SIMD usada desde Python

**Alumno:** Braulio Michel Torres Diaz
**Tema:** Aceleración de multiplicación de matrices con AVX2 Intrinsics  
**Código:** Multiplicación de matrices (HPC — O(N³) operaciones)

---

## ¿Qué hace este proyecto?

Se implementó la multiplicación de matrices `C = A × B` de tres formas distintas:

| Versión | Dónde vive | Cómo se llama |
|---|---|---|
| **Naive (escalar)** | `matmul.cpp` → función `matmul_naive` | Bucle triple clásico en C++ |
| **AVX2 (SIMD)** | `matmul.cpp` → función `matmul_avx2` | Intrinsics de 256 bits + tiling de caché |
| **NumPy / BLAS** | `benchmark.py` | Referencia (techo teórico) |

Ambas funciones C++ se compilan como biblioteca compartida (`libmatmul.so`) y se llaman desde Python usando **ctypes**, pasando arreglos de NumPy directamente.

---

## Estructura de archivos

```
simd_matmul/
├── matmul.cpp          ← Código fuente C++ con intrinsics AVX2
├── libmatmul.so        ← Biblioteca ya compilada (lista para usar)
├── benchmark.py        ← Script Python: carga la .so y compara las 3 versiones
├── test_no_numpy.py    ← Prueba de correctitud (sin dependencias externas)
└── Makefile            ← Para compilar / recompilar fácilmente
```

---

## Cómo verificar que funciona

### Paso 1 — Prueba de correctitud (sin instalar nada extra)

Verifica que `matmul_naive` y `matmul_avx2` producen el mismo resultado correcto
usando una multiplicación manual de 2×3 · 3×2 que se puede calcular a mano:

```bash
python3 test_no_numpy.py
```

**Salida esperada:**
```
=== Prueba de correctitud (2×3 · 3×2) ===
  Referencia: [58.0, 64.0, 139.0, 154.0]
  Naive:      [58.0, 64.0, 139.0, 154.0]
  AVX2:       [58.0, 64.0, 139.0, 154.0]
  Naive ✓ PASS   AVX2 ✓ PASS

=== Mini-benchmark 128×128 (float32) ===
  Naive : X.XX ms  |  XX.XX GFLOP/s
  AVX2  : X.XX ms  |  XX.XX GFLOP/s
  Aceleración: X.X×
```

✅ Si aparece `✓ PASS` en ambas versiones, los intrinsics calculan correctamente.

---

### Paso 2 — Benchmark completo con NumPy (512×512)

```bash
python3 benchmark.py
```

**Salida esperada (valores aproximados según la máquina):**
```
Matrices: A=512×512  B=512×512  (float32)

Implementación       Tiempo (s)    GFLOP/s  Aceleración
────────────────────────────────────────────────────────
C++ Naive               ~0.029       ~9.2        1.00×
C++ AVX2                ~0.020      ~13.7        1.49×   ← SIMD es más rápido
NumPy (BLAS)            ~0.008      ~32.3        3.49×   ← techo de referencia
────────────────────────────────────────────────────────

Verificación de correctitud (vs referencia float64):
  Error máximo Naive     : ~9e-05   ← error normal de float32
  Error máximo AVX2      : ~9e-05   ← mismo error → mismos resultados
  Error máximo NumPy     : ~5e-05
```

✅ Puntos clave a observar:
- AVX2 es **~1.5× más rápido** que el código naive.
- El **error numérico de AVX2 ≡ Naive** → los intrinsics no introducen errores adicionales.
- NumPy/BLAS es el techo (usa rutinas en ensamblador + multihilo).

---

### Paso 3 — Recompilar desde cero (opcional)

Si se quiere verificar que la biblioteca se genera desde el fuente:

```bash
make clean   # borra libmatmul.so
make         # recompila con: g++ -O3 -march=native -mavx2 -mfma -ffast-math -shared -fPIC
make test    # corre test_no_numpy.py
make run     # corre benchmark.py
```

---

## Qué son los intrinsics AVX2 (explicación técnica)

Los **intrinsics** son funciones especiales de C++ que mapean directamente a **instrucciones del procesador**, saltándose el compilador. Se usan cuando se quiere control total sobre el hardware.

### Intrinsics usados en este proyecto

| Intrinsic | Instrucción CPU | Qué hace |
|---|---|---|
| `_mm256_set1_ps(x)` | `VBROADCASTSS` | Copia un `float` a los 8 lanes del registro de 256 bits |
| `_mm256_loadu_ps(ptr)` | `VMOVUPS` | Carga 8 floats consecutivos de memoria a un registro AVX |
| `_mm256_fmadd_ps(a,b,c)` | `VFMADD213PS` | Calcula `a*b + c` en **un solo ciclo** (Fused Multiply-Add) |
| `_mm256_storeu_ps(ptr,v)` | `VMOVUPS` | Guarda 8 floats de un registro AVX a memoria |

### ¿Por qué es más rápido?

Un procesador moderno puede procesar **8 floats en paralelo** (ancho de registro AVX = 256 bits = 8 × 32 bits).
La versión naive procesa **1 float por ciclo**. La versión AVX2 procesa **8 floats por ciclo** → ganancia teórica de 8×.

En la práctica se obtiene ~1.5× porque el cuello de botella pasa a ser el **ancho de banda de memoria** (latencia de caché), no la ALU. Por eso se añadió **tiling de caché**: dividir las matrices en bloques que caben en L2 para maximizar la reutilización de datos.

---

## Cómo se llama la biblioteca desde Python

```python
import ctypes, numpy as np, pathlib

# 1. Cargar la .so
lib = ctypes.CDLL("libmatmul.so")

# 2. Declarar la firma de la función
lib.matmul_avx2.restype  = None
lib.matmul_avx2.argtypes = [
    ctypes.POINTER(ctypes.c_float),  # A
    ctypes.POINTER(ctypes.c_float),  # B
    ctypes.POINTER(ctypes.c_float),  # C (salida)
    ctypes.c_int,                    # M
    ctypes.c_int,                    # K
    ctypes.c_int,                    # N
]

# 3. Crear arreglos NumPy float32 y obtener puntero C
A = np.random.randn(512, 512).astype(np.float32)
B = np.random.randn(512, 512).astype(np.float32)
C = np.zeros((512, 512), dtype=np.float32)

ptr = lambda arr: arr.ctypes.data_as(ctypes.POINTER(ctypes.c_float))

# 4. Llamar a la función C++ desde Python
lib.matmul_avx2(ptr(A), ptr(B), ptr(C), 512, 512, 512)
```

La clave es que `ctypes` obtiene el **puntero directo** al buffer de NumPy — no hay copia de datos. La función C++ escribe directamente en la memoria del arreglo Python.

---

## Requisitos del sistema

- **CPU:** Intel/AMD con soporte AVX2 (cualquier CPU desde ~2013)
- **Compilador:** `g++ >= 7` con flags `-mavx2 -mfma`
- **Python:** 3.8+ con `ctypes` (incluido en la librería estándar)
- **NumPy:** solo para `benchmark.py` (instalar con `pip install numpy`)

Verificar soporte AVX2 en Linux:
```bash
grep -m1 "avx2" /proc/cpuinfo && echo "AVX2 disponible"
```
